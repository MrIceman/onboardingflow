package com.nowocode.lib

import android.app.Activity
import android.content.Context
import android.view.View

interface OnboardingManager {

    fun setActivity(activity: Activity): OnboardingManager

    fun addOnboardingFeature(
        view: View,
        text: String,
        onNext: (() -> Unit)? = null
    ): OnboardingManager

    fun start()


    companion object {
        fun instance(context: Context): OnboardingManager = OnboardingManagerImpl(context)
    }
}