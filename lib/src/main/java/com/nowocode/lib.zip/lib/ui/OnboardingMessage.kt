package com.nowocode.lib.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.annotation.RequiresApi

class OnboardingMessage : FrameLayout {
    private val backgroundPaint = Paint()
    private val trianglePaint = Paint()
    private var title: String = "Title"
    private var text: String = "blabla"
    private val scale = context.resources.displayMetrics.density
    private val PADDING_IN_DP = 8 * scale

    // if is Top is true then the dialog triangle is at the bottom, reverse else
    var isTop: Boolean = true

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        setUpBackgroundPaint()
    }

    fun setContent(title: String, text: String) {
        this.title = title
        this.text = text
    }

    private fun setUpBackgroundPaint() {
        backgroundPaint.color = Color.WHITE
        backgroundPaint.style = Paint.Style.FILL

        trianglePaint.color = Color.BLACK
        trianglePaint.style = Paint.Style.FILL
        setWillNotDraw(false)
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onDraw(canvas: Canvas?) {
        val dialogWidth = width * 0.85
        val lineWidth = 30 * scale
        canvas?.drawRoundRect(
            PADDING_IN_DP * 2,
            PADDING_IN_DP,
            width.toFloat() - PADDING_IN_DP * 2,
            height.toFloat(),
            15f,
            15f,
            backgroundPaint
        )

        /*
        canvas?.drawArc(
            width.toFloat() / 2 - lineWidth,
            0f,
            width.toFloat() / 2 + lineWidth,
            PADDING_IN_DP * 4,
            0f,
            90f,
            true,
            trianglePaint
        )

         */
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {

        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }
}